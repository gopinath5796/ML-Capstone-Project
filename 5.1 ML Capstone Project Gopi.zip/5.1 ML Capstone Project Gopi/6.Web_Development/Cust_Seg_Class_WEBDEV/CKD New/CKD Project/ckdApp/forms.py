from django import forms
from .models import *


class ckdForm(forms.ModelForm):
    class Meta():
        model=ckdModel
        fields=['Average_Spending', 'Total_Spent', 'Last_Visit_Days', 'Mobile_App_Usage', 'Email_Response_Rate']
