from django.db import models

# Create your models here.
class ckdModel(models.Model):

    Average_Spending=models.FloatField()
    Total_Spent=models.FloatField()
    Last_Visit_Days=models.FloatField()
    Mobile_App_Usage=models.FloatField()
    Email_Response_Rate=models.FloatField()
